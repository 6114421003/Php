<?php include 'home.php';?>

    <div class="row">
    <div class="col-sm-12 col-md-1 col-lg-1">
                </div>  
                <div class="col-sm-12 col-md-10 col-lg-10">
                <h2 style="text-align:center;">ระดับสมาชิก</h2>
                <br>
                <table class="table table-borderless">
                    <table class="table table-bordered table-striped">
                            <thead>
                            <tr>
                                <th colspan="1">รหัส</th>
                                <th colspan="1"  >ชื่อระดับ</th>
                                <th colspan="1"  >ส่วนลด</th>
                                <th colspan="1" >ระยะเวลาสมาชิก(เดือน)</th>
                                <th colspan="1"></th>
                            </tr>                
                        </thead>
                        <tbody  >
                            <?php
                                include 'connectdb.php';
                                $sql =  'SELECT * FROM class order by cls_id';
                                $result = mysqli_query($conn,$sql);
                                while (($row = mysqli_fetch_array($result, MYSQLI_ASSOC)) != NULL) {
                                    echo '<tr>';
                                    echo '<td>' . $row['cls_id'] . '</td>';
                                    echo '<td>' . $row['cls_name'] . '</td>';
                                    echo '<td>' . $row['cls_dis'] . '</td>';
                                    echo '<td>' . $row['cls_date'] . '</td>';
                                   
                                    echo '<td>';
                            ?>
                                <a href="class_edit.php?cls_id=<?php echo $row['cls_id'];?>" class="btn btn-warning">แก้ไข</a>
                                <a href="JavaScript:if(confirm('ยืนยันการลบ')==true){window.location='class_delete.php?cls_id=<?php echo $row["cls_id"];?>'}" class="btn btn-danger">ลบ</a>
                            <?php
                                    echo '</td>';
                                    echo '</tr>';
                                }
                                mysqli_free_result($result);
                                mysqli_close($conn);
                            ?>
                        </tbody>    
                    </table>
                    </table>
                   <a href="class_add.php" class="btn btn-outline-success"  style="text-align:right;"  >  เพิ่มระดับสมาชิก</a>
                </div>    
            
                </div>
           
            <div >
                <?php include 'footer.php';?>
            </div>

    </body>
</html>