<?php include 'home.php';?>

    <div class="row">
                <div class="col-sm-12 col-md-1 col-lg-1">
                </div>  
                <div class="col-sm-12 col-md-10 col-lg-10">
                <h2 style="text-align:center;">แก้ไขระดับสมาชิก</h2>
                <br>
                <?php
                    include 'connectdb.php';
                    if(isset($_GET['submit'])){
                        $cls_id     = $_GET['cls_id'];
                        $cls_name   = $_GET['cls_name'];
                        $cls_dis   = $_GET['cls_dis'];
                        $cls_date   = $_GET['cls_date'];
                        $sql        = "update class set cls_name='$cls_name',cls_dis='$cls_dis',cls_date='$cls_date' where cls_id='$cls_id'";
                        mysqli_query($conn,$sql);
                        mysqli_close($conn);
                        echo "แก้ไขระดับสมาชิก $cls_name $cls_name เรียบร้อยแล้ว<br>";
                        echo '<a href="class_list.php">แสดงระดับสมาชิกทั้งหมด</a>';
                    }else{
                        $fcls_id = $_REQUEST['cls_id'];
                        $sql =  "SELECT * FROM class where cls_id='$fcls_id'";
                        $result = mysqli_query($conn,$sql);
                        $row = mysqli_fetch_array($result, MYSQLI_ASSOC);
                        $fcls_name = $row['cls_name'];
                        $fcls_dis = $row['cls_dis'];
                        $fcls_date = $row['cls_date'];
                        mysqli_free_result($result);
                        mysqli_close($conn);                        
                ?>
                    <form class="form-horizontal" role="form" name="tools_edit" action="<?php echo $_SERVER['PHP_SELF']?>">
                        <input type="hidden" name="cls_id" id="cls_id" value="<?php echo "$fcls_id";?>">
                        <div class="form-group">
                            <label for="cls_name" class="col-md-2 col-lg-2 control-label">ระดับ</label>
                            <div class="col-md-10 col-lg-10">
                                <input type="text" name="cls_name" id="cls_name" class="form-control" value="<?php echo "$fcls_name";?>">
                            </div>    
                        </div>
                        <div class="form-group">
                            <label for="cls_dis" class="col-md-2 col-lg-2 control-label">ส่วนลด</label>
                            <div class="col-md-10 col-lg-10">
                                <input type="text" name="cls_dis" id="cls_dis" class="form-control" value="<?php echo "$fcls_dis";?>">
                            </div>    
                        </div>
                        <div class="form-group">
                            <label for="cls_date" class="col-md-2 col-lg-2 control-label">ระยะเวลาสมาชิก(เดือน)</label>
                            <div class="col-md-10 col-lg-10">
                                <input type="text" name="cls_date" id="cls_date" class="form-control" value="<?php echo "$fcls_date";?>">
                            </div>    
                        </div>
                        
                        <div class="form-group">
                            <div class="col-md-10 col-lg-10">
                                <input type="submit" name="submit" value="ตกลง" class="btn btn-default">
                            </div>    
                        </div>
                    </form>
                <?php
                    }
                ?>
                 </div>    
            </div>
           
            <div >
                <?php include 'footer.php';?>
            </div>

    </body>
</html>