-- phpMyAdmin SQL Dump
-- version 4.9.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Mar 22, 2020 at 07:00 PM
-- Server version: 10.4.8-MariaDB
-- PHP Version: 7.3.11

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `movie`
--

-- --------------------------------------------------------

--
-- Table structure for table `class`
--

CREATE TABLE `class` (
  `cls_id` int(10) NOT NULL,
  `cls_name` varchar(50) DEFAULT NULL,
  `cls_dis` varchar(50) DEFAULT NULL,
  `cls_date` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `class`
--

INSERT INTO `class` (`cls_id`, `cls_name`, `cls_dis`, `cls_date`) VALUES
(2, 'silver', '5%', '1'),
(3, 'gold', '15%', '2');

-- --------------------------------------------------------

--
-- Table structure for table `member`
--

CREATE TABLE `member` (
  `mem_id` int(10) NOT NULL,
  `mem_fname` varchar(30) DEFAULT NULL,
  `mem_lname` varchar(30) DEFAULT NULL,
  `mem_number` varchar(50) CHARACTER SET utf32 DEFAULT NULL,
  `mem_birth` varchar(50) DEFAULT NULL,
  `mem_date` varchar(50) DEFAULT NULL,
  `mem_cls_id` int(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `member`
--

INSERT INTO `member` (`mem_id`, `mem_fname`, `mem_lname`, `mem_number`, `mem_birth`, `mem_date`, `mem_cls_id`) VALUES
(2, 'ฟฟฟฟฟ', NULL, 'หหหหหหห', '1998/0/21', '2020/02/01', 3);

-- --------------------------------------------------------

--
-- Stand-in structure for view `member_detail`
-- (See below for the actual view)
--
CREATE TABLE `member_detail` (
`mem_id` int(10)
,`mem_fname` varchar(30)
,`mem_lname` varchar(30)
,`mem_number` varchar(50)
,`mem_birth` varchar(50)
,`mem_date` varchar(50)
,`cls_name` varchar(50)
);

-- --------------------------------------------------------

--
-- Table structure for table `movie`
--

CREATE TABLE `movie` (
  `mov_id` int(10) NOT NULL,
  `mov_tname` varchar(50) DEFAULT NULL,
  `mov_ename` varchar(30) DEFAULT NULL,
  `mov_date` date DEFAULT NULL,
  `mov_per` varchar(50) DEFAULT NULL,
  `mov_time` varchar(30) DEFAULT NULL,
  `mov_price` varchar(50) DEFAULT NULL,
  `mov_sta_id` int(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `movie`
--

INSERT INTO `movie` (`mov_id`, `mov_tname`, `mov_ename`, `mov_date`, `mov_per`, `mov_time`, `mov_price`, `mov_sta_id`) VALUES
(2, 'กกกกกกก', 'aaaaaaaaa', '2020-04-14', 'MTHAI', '2:32', '180', 2);

-- --------------------------------------------------------

--
-- Stand-in structure for view `movie_detail`
-- (See below for the actual view)
--
CREATE TABLE `movie_detail` (
`mov_id` int(10)
,`mov_tname` varchar(50)
,`mov_ename` varchar(30)
,`mov_date` date
,`mov_per` varchar(50)
,`mov_price` varchar(50)
,`sta_name` varchar(50)
);

-- --------------------------------------------------------

--
-- Table structure for table `status_movie`
--

CREATE TABLE `status_movie` (
  `sta_id` int(10) NOT NULL,
  `sta_name` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `status_movie`
--

INSERT INTO `status_movie` (`sta_id`, `sta_name`) VALUES
(2, 'coming soon'),
(3, 'กำลังฉาย');

-- --------------------------------------------------------

--
-- Structure for view `member_detail`
--
DROP TABLE IF EXISTS `member_detail`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `member_detail`  AS  select `member`.`mem_id` AS `mem_id`,`member`.`mem_fname` AS `mem_fname`,`member`.`mem_lname` AS `mem_lname`,`member`.`mem_number` AS `mem_number`,`member`.`mem_birth` AS `mem_birth`,`member`.`mem_date` AS `mem_date`,`class`.`cls_name` AS `cls_name` from (`member` join `class` on(`member`.`mem_cls_id` = `class`.`cls_id`)) order by `member`.`mem_id` ;

-- --------------------------------------------------------

--
-- Structure for view `movie_detail`
--
DROP TABLE IF EXISTS `movie_detail`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `movie_detail`  AS  select `mov_id` AS `mov_id`,`mov_tname` AS `mov_tname`,`mov_ename` AS `mov_ename`,`mov_date` AS `mov_date`,`mov_per` AS `mov_per`,`mov_price` AS `mov_price`,`status_movie`.`sta_name` AS `sta_name` from (`movie` join `status_movie` on(`mov_sta_id` = `status_movie`.`sta_id`)) order by `mov_id` ;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `class`
--
ALTER TABLE `class`
  ADD PRIMARY KEY (`cls_id`);

--
-- Indexes for table `member`
--
ALTER TABLE `member`
  ADD PRIMARY KEY (`mem_id`),
  ADD KEY `mem_cls_id` (`mem_cls_id`);

--
-- Indexes for table `movie`
--
ALTER TABLE `movie`
  ADD PRIMARY KEY (`mov_id`),
  ADD KEY `mov_std_id` (`mov_sta_id`);

--
-- Indexes for table `status_movie`
--
ALTER TABLE `status_movie`
  ADD PRIMARY KEY (`sta_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `class`
--
ALTER TABLE `class`
  MODIFY `cls_id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `member`
--
ALTER TABLE `member`
  MODIFY `mem_id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `movie`
--
ALTER TABLE `movie`
  MODIFY `mov_id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `status_movie`
--
ALTER TABLE `status_movie`
  MODIFY `sta_id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
