<?php include 'home.php';?>

    <div class="row">
                <div class="col-sm-12 col-md-1 col-lg-1">
                </div>  
                <div class="col-sm-12 col-md-10 col-lg-10">
                <h2 style="text-align:center;">เพิ่มข้อมูลภาพยนต์</h2>
                <br>
                <?php
                        if(isset($_GET['submit'])){
                            $mov_sta_id = $_GET['mov_sta_id'];
                            $mov_tname = $_GET['mov_tname'];
                            $mov_ename = $_GET['mov_ename'];
                            $mov_date= $_GET['mov_date'];
                            $mov_per= $_GET['mov_per'];
                            $mov_time= $_GET['mov_time'];
                            $mov_price= $_GET['mov_price'];
                            
                            $sql = "insert into movie (mov_sta_id,mov_tname,mov_ename,mov_date,mov_per,mov_time,mov_price)";
                            $sql .= " values ('$mov_sta_id','$mov_tname','$mov_ename','$mov_date','$mov_per','$mov_time','$mov_price')";
                            echo $sql;
                            include 'connectdb.php';
                            mysqli_query($conn,$sql);
                            mysqli_close($conn);
                            echo "เพิ่มข้อมูลภาพยนต์ $mov_tname  เรียบร้อยแล้ว<br>";
                            echo '<a href="movie_list.php">แสดงข้อมูลภาพยนต์</a>';
                        }else{
                    ?>
                    <form class="form-horizontal" role="form" name="games_add" action="<?php echo $_SERVER['PHP_SELF'];?>">
                        
                        <div class="form-group">
                            <label for="mov_tname" class="col-md-2 col-lg-2 control-label">ชื่อภาพยนต์(ไทย)</label>
                            <div class="col-md-10 col-lg-10">
                                <input type="text" name="mov_tname" id="mov_tname" class="form-control">
                            </div>    
                        </div>    
                        <div class="form-group">
                            <label for="mov_ename" class="col-md-2 col-lg-2 control-label">ชื่อภาพยนต์(อังกฤษ)</label>
                            <div class="col-md-10 col-lg-10">
                                <input type="text" name="mov_ename" id="mov_ename" class="form-control">
                            </div>    
                        </div> 
                        <div class="form-group">
                            <label for="mov_date" class="col-md-2 col-lg-2 control-label">วันเปิดตัว</label>
                            <div class="col-md-10 col-lg-10">
                                <input type="text" name="mov_date" id="mov_date" class="form-control">
                                <h6 > ปี/เดือน/วัน </h6> 
                            </div>    
                        </div>
                        <br>
                       
                        <div class="form-group">
                            <label for="mov_per" class="col-md-2 col-lg-2 control-label">ผู้กำกับ</label>
                            <div class="col-md-10 col-lg-10">
                                <input type="text" name="mov_per" id="mov_per" class="form-control">
                            </div>    
                        </div>
                        
                        <div class="form-group">
                            <label for="mov_time" class="col-md-2 col-lg-2 control-label">ระยะเวลาหนัง</label>
                            <div class="col-md-10 col-lg-10">
                                <input type="text" name="mov_time" id="mov_time" class="form-control">
                                <h6 > (ชั่วโมง:นาที) </h6> 
                            </div>    
                        </div>
                        <div class="form-group">
                            <label for="mov_price" class="col-md-2 col-lg-2 control-label">ราคาตั๋ว</label>
                            <div class="col-md-10 col-lg-10">
                                <input type="text" name="mov_price" id="mov_price" class="form-control">
                            </div>    
                        </div>
                        <div class="form-group">
                            <label for="mov_sta_id" class="col-md-2 col-lg-2 control-label">สถานะ</label>
                            <div class="col-md-10 col-lg-10">
                                <select name="mov_sta_id" id="mov_sta_id" class="form-control">
                                <?php
                                    include 'connectdb.php';
                                    $sql =  'SELECT * FROM status_movie '
                                            . 'order by sta_id';
                                    $result = mysqli_query($conn,$sql);
                                    while (($row = mysqli_fetch_array($result, MYSQLI_ASSOC)) != NULL) {
                                        echo '<option value=';
                                        echo '"' . $row['sta_id'] . '">';
                                        echo $row['sta_name'];
                                        echo '</option>';
                                    }
                                    mysqli_free_result($result);
                                    mysqli_close($conn);
                                ?>
                                </select>
                           </div>    
                        </div>
                        
                        <div class="form-group">
                            <div class="col-md-10 col-lg-10">
                                <input type="submit" name="submit" value="ตกลง" class="btn btn-default">
                            </div>    
                        </div> 
                    </form>
                    <?php
                        }
                    ?>
                    </div>    
            </div>
            <div >
                <?php include 'footer.php';?>
            </div>
  

    </body>
</html>