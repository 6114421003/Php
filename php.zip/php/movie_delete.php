<?php include 'home.php';?>
 
   
    <div class="row">
                <div class="col-sm-12 col-md-1 col-lg-1">
                </div>  
                <div class="col-sm-12 col-md-10 col-lg-10">
                <h2 style="text-align:center;">ลบข้อมูลภาพยนต์</h2>
                <br>
                <?php
            include 'connectdb.php';
            $mov_id = $_GET['mov_id'];
            $sql = "delete from movie where mov_id='$mov_id'";
            $result = mysqli_query($conn,$sql);
            if($result){
                echo 'ลบแล้ว';
            }else{
                echo 'ลบไม่ได้';
            }
            mysqli_close($conn);
            echo '<a href="movie_list.php">แสดงข้อมูลภาพยนต์ทั้งหมด</a>';
        ?>
         </div>    
            </div>
           
            <div >
                <?php include 'footer.php';?>
            </div>

    </body>
</html>