<!DOCTYPE html>
<html lang="en">
<head>
  <title>PROJECT</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js"></script>

</head>
<body>

<?php include 'home.php';?>

<div class="container">
        <div class="row">
          <div class="col-xl-4">
                <div class="card bg-dark text-white">
                 <img src="https://www.wallpaperup.com/uploads/wallpapers/2013/10/29/166754/8b8d25817cabfa8f60c1981f50dceb3f.jpg"  class="media" width="1110" heigth="500" alt="...">
                           <div class="card-img-overlay">
                           <h5 class="card-title">Card title</h5>
                          <p class="card-text">This is a wider card with supporting text below as a natural lead-in to additional content. This content is a little bit longer.</p>
                          <p class="card-text">Last updated 3 mins ago</p>
                         </div>
                      </div>
                      </div>
        </div>
      </div>


<br>
<br>   

 <div class="container">
        <div class="row">
          <div class="col-xl-12">
          
          <div class="media">
                     <img class="mr-3" src="https://www.wallpaperup.com/uploads/wallpapers/2013/10/27/165834/2c70b588eda4cc8d171af71f7a3d0962-1000.jpg" width="120" heigth="120"alt="Generic placeholder image">
                         <div class="media-body">
                              <h5 class="mt-0">Media heading</h5>
                              Cras sit amet nibh libero, in gravida nulla. Nulla vel metus scelerisque ante sollicitudin. Cras purus odio, vestibulum in vulputate at, tempus viverra turpis. Fusce condimentum nunc ac nisi vulputate fringilla. Donec lacinia congue felis in faucibus.
<br>
                          <div class="media mt-3">
                              <a class="pr-3" href="#">
                                   <img src="https://www.wallpaperup.com/uploads/wallpapers/2013/10/27/165854/ef6032a6999b8ea2aae95f5301ea6922-1000.jpg" width="120" heigth="120" alt="Generic placeholder image">
                                      </a>
                                <div class="media-body">
                               <h5 class="mt-0">Media heading</h5>
                                Cras sit amet nibh libero, in gravida nulla. Nulla vel metus scelerisque ante sollicitudin. Cras purus odio, vestibulum in vulputate at, tempus viverra turpis. Fusce condimentum nunc ac nisi vulputate fringilla. Donec lacinia congue felis in faucibus.
                                </div>
                            </div>
                         </div>
                  </div>

            </div>
        </div>
      </div>
      <br>
      <br>
    </body>
</html>