<?php include 'home.php';?>

    <div class="row">
                <div class="col-sm-12 col-md-1 col-lg-1">
                </div>  
                <div class="col-sm-12 col-md-10 col-lg-10">
                <h2 style="text-align:center;">เพิ่มระดับสมาชิก</h2>
                <br>
                <?php
                    if(isset($_GET['submit'])){
                        $cls_name = $_GET['cls_name'];
                        $cls_dis = $_GET['cls_dis'];
                        $cls_date = $_GET['cls_date'];
                        $sql = "insert into class (cls_name,cls_dis,cls_date) values ('$cls_name','$cls_dis','$cls_date')";
                        echo $sql;
                        include 'connectdb.php';
                        mysqli_query($conn,$sql);
                        mysqli_close($conn);
                        echo "เพิ่มระดับสมาชิก $cls_name $cls_dis เรียบร้อยแล้ว<br>";
                        echo '<a href=class_list.php>แสดงระดับสมาชิกทั้งหมด</a>';
                    }else{
                ?>
                    <form class="form-horizontal" role="form" name="type_manga_add" action="<?php echo $_SERVER['PHP_SELF']?>">
                        <div class="form-group">
                            <label for="cls_name" class="col-md-2 col-lg-2 control-label">ระดับ</label>
                            <div class="col-md-10 col-lg-10">
                                <input type="text" name="cls_name" id="cls_name" class="form-control">
                            </div>    
                        </div>
                        <div class="form-group">
                            <label for="cls_dis" class="col-md-2 col-lg-2 control-label">ส่วนลด</label>
                            <div class="col-md-10 col-lg-10">
                                <input type="text" name="cls_dis" id="cls_dis" class="form-control">
                            </div>    
                        </div>
                        <div class="form-group">
                            <label for="cls_date" class="col-md-2 col-lg-2 control-label">ระยะเวลาสมาชิก(เดือน)</label>
                            <div class="col-md-10 col-lg-10">
                                <input type="text" name="cls_date" id="cls_date" class="form-control">
                            </div>    
                        </div>
                        
                        
                        <div class="form-group">
                            <div class="col-md-10 col-lg-10">
                                <input type="submit" name="submit" value="ตกลง" class="btn btn-default">
                            </div>    
                        </div>
                    </form>
                <?php
                    }
                ?>
                 </div>    
            </div>
           
            <div >
                <?php include 'footer.php';?>
            </div>

    </body>
</html>