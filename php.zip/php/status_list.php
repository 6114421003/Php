<?php include 'home.php';?>

    <div class="row">
                <div class="col-sm-12 col-md-1 col-lg-1">
                </div>  
                <div class="col-sm-12 col-md-10 col-lg-10">
                <h2 style="text-align:center;">สถานะภาพยนต์</h2>
                <br>
                <table class="table table-borderless">
                <table class="table table-bordered table-striped">
                        <thead>
                            <tr>
                                <th >รหัส</th>
                                <th colspan="1" >สถานะ</th>
                                <th colspan="1"></th>
                            </tr>                
                        </thead>
                        <tbody >
                            <?php
                                include 'connectdb.php';
                                $sql =  'SELECT * FROM status_movie order by sta_id';
                                $result = mysqli_query($conn,$sql);
                                while (($row = mysqli_fetch_array($result, MYSQLI_ASSOC)) != NULL) {
                                    echo '<tr>';
                                    echo '<td>' . $row['sta_id'] . '</td>';
                                    echo '<td>' . $row['sta_name'] . '</td>';
                                   
                                    echo '<td>';
                            ?>
                                <a href="status_edit.php?sta_id=<?php echo $row['sta_id'];?>" class="btn btn-warning">แก้ไข</a>
                                <a href="JavaScript:if(confirm('ยืนยันการลบ')==true){window.location='status_delete.php?sta_id=<?php echo $row["sta_id"];?>'}" class="btn btn-danger">ลบ</a>
                            <?php
                                    echo '</td>';
                                    echo '</tr>';
                                }
                                mysqli_free_result($result);
                                mysqli_close($conn);
                            ?>
                        </tbody>    
                    </table>
                    </table>
                   <a href="status_add.php" class="btn btn-outline-success"  style="text-align:right;"  >  เพิ่มสถานะ</a>
                </div>    
            </div>
           
            <div >
                <?php include 'footer.php';?>
            </div>

    </body>
</html>