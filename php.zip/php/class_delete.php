<?php include 'home.php';?>

    <div class="row">
                <div class="col-sm-12 col-md-1 col-lg-1">
                </div>  
                <div class="col-sm-12 col-md-10 col-lg-10">
                <h2 style="text-align:center;">ลบระดับสมาชิก</h2>
                <br>
                <?php
            include 'connectdb.php';
            $cls_id = $_GET['cls_id'];
            $sql = "delete from class where cls_id='$cls_id'";
            $result = mysqli_query($conn,$sql);
            if($result){
                echo 'ลบแล้ว';
            }else{
                echo 'ลบไม่ได้';
            }
            mysqli_close($conn);
            echo '<a href="class_list.php">แสดงระดับสมาชิกทั้งหมด</a>';
        ?>
                 </div>    
            </div>
           
  
            <div >
                <?php include 'footer.php';?>
            </div>
    </body>
</html>