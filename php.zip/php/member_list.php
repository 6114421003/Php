<?php include 'home.php';?>

    <div class="row">
                <div class="col-sm-12 col-md-1 col-lg-1">
                </div>  
                <div class="col-sm-12 col-md-10 col-lg-10">
                <h2 style="text-align:center;">ข้อมูลสมาชิก</h2>
                <br>
                <table class="table table-borderless">
                   
                    <table class="table table-bordered table-striped">
                            <thead>
                                <tr>
                                    <th>รหัส</th>
                                    <th colspan="1">ชื่อ-นามสกุล</th>
                                    <th colspan="1">เบอร์มือถือ</th>
                                    <th colspan="1">วันเกิด</th>
                                    <th colspan="1">วันที่เป็นสมาชิก</th>
                                    <th colspan="1">ระดับสมาชิก</th>
                                    <th colspan="1"></th>
                                </tr>
                            </thead>
                            <tbody>
                    <?php
                        include 'connectdb.php';                        
                        $sql =  'select mem_id,mem_fname,mem_lname,mem_number,mem_birth,mem_date,cls_name
                        from member join class on mem_cls_id=cls_id
                        order by mem_id';
                        $result = mysqli_query($conn,$sql);
                        while (($row = mysqli_fetch_array($result, MYSQLI_ASSOC)) != NULL) {
                            echo '<tr>';
                            echo '<td>' . $row['mem_id'] . '</td>';
                            echo '<td>' . $row['mem_fname'].''. $row['mem_lname'];
                            echo '<td>' . $row['mem_number'].'</td>';
                            echo '<td>' . $row['mem_birth'].'</td>';
                            echo '<td>' . $row['mem_date'].'</td>';
                            echo '<td>' . $row['cls_name'].'</td>';
                            echo '<td>';
                            ?>
                                <a href="member_edit.php?mem_id=<?php echo $row['mem_id'];?>" class="btn btn-warning">แก้ไข</a>
                                <a href="JavaScript:if(confirm('ยืนยันการลบ')==true)
                                   {window.location='member_delete.php?mem_id=<?php echo $row["mem_id"];?>'}" class="btn btn-danger">ลบ</a>
                            <?php
                                    echo '</td>';                            
                            echo '</tr>';
                        }
                        mysqli_free_result($result);
                        echo '</table>';
                        mysqli_close($conn);
                    ?>
                            </tbody>
                        </table>    
                    </table>
                   <a href="member_add.php" class="btn btn-outline-success"  style="text-align:right;"  >  เพิ่มข้อมูลสมาชิก</a>
                </div>    
            </div>
           
            <div >
                <?php include 'footer.php';?>
            </div>

    </body>
</html>