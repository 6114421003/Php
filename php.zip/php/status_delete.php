<?php include 'home.php';?>

    <div class="row">
                <div class="col-sm-12 col-md-1 col-lg-1">
                </div>  
                <div class="col-sm-12 col-md-10 col-lg-10">
                <h2 style="text-align:center;">ลบสถานะภาพยนต์</h2>
                <br>
                <?php
            include 'connectdb.php';
            $sta_id = $_GET['sta_id'];
            $sql = "delete from status_movie where sta_id='$sta_id'";
            $result = mysqli_query($conn,$sql);
            if($result){
                echo 'ลบแล้ว';
            }else{
                echo 'ลบไม่ได้';
            }
            mysqli_close($conn);
            echo '<a href="status_list.php">แสดงสถานะทั้งหมด</a>';
        ?>
                </div>    
            </div>
           
            <div >
                <?php include 'footer.php';?>
            </div>

    </body>
</html>